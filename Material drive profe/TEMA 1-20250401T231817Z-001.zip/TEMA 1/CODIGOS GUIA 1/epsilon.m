%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% UNIVERSIDAD AUTONOMA DE OCCIDENTE
% DEPTO. DE ENERGETICA Y MECANICA
% MECANICA COPUTACIONAL
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Prof. Enrique Franco G.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% C�lculo de la precisi�n de la 
% em�quina
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

e = 1.0;
while(1.0 +e/2.0 > 1.0)
	e = e/2.0;
end 
e