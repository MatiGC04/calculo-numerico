function [emaq] = eps_maq()
x = 1.0;
while ((1+x)~=1)
    x = x/2;
end
emaq=x;
%clear all
