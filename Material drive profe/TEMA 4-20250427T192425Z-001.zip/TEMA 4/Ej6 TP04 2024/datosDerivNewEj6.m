function df = datosDerivNewEj6(x)

df = 35000000 - (401000/(x^2)) + ((2*17122.7)/(x^3));
