function f = datosNewEj6(x)

f = 35000000*x +401000/(x) - 17122.7/(x^2)-1494500;
